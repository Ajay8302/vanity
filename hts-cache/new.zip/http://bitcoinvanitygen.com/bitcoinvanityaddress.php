 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>BitcoinVanityGen.com - Bitcoin Vanity Address Generator Online, Free Bitcoin Vanity Address Generaton</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta name="robot" content="index, follow">
<meta name="Description" content="Bitcoin vanity address generator online, secure, easy, fast and free. Generate your Bitcoin address online"/>
<meta name="Keywords" content="bitcoin vanity address generator online, bitcoin, vanity, address, generator, custom address, custom bitcoin address, bitcoin vanity address generator, bitcoin vanity address, bitcoin vanity, bitcoin address generator, free bitcoin address, online, free"/>
<link rel="stylesheet" href="btc.css" type="text/css">
<link rel="stylesheet" href="pure.css">
</head>
<body style="margin: 0px; padding 0px;background: #454545;">
<table width="60%" align="center" border="0" cellspacing="0" cellpadding="0">
<tr id="5228582">
<td align="center" colspan="6">
<br><br><br>
<a href="bitcoinvanityaddress.php" alt="Bitcoin Vanity Address FAQ" title="Bitcoin Vanity Address FAQ"><span style="color: #979797;">What is Bitcoin Vanity address? | FAQ | Contact</span></a>
<br><br>
</td>
</tr>
<tr id="55252">
<td width="20%" align="right" class="genmed" valign="top">
<br><br>
<table>
<tr>
<td colspan="3" class="grey"><b>Characters:</b></td>
</tr>
<tr>
<td class="grey">1&nbsp;&nbsp;</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">2</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">3</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">4</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">5</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">6 </td><td class="grey" style="color:#00cc00">free</td>
</tr>
<tr>
<td class="grey">7</td><td class="grey">0.06 BTC</td>
</tr>
<tr>
<td class="grey">8 </td><td class="grey">0.3 BTC</td>
</tr>
<tr>
<td class="grey">9</td><td class="grey">0.8 BTC</td>
</tr>
</table>
</td>
<td width="20%" align="center"><a href="index.php" alt="bitcoin vanity" title="bitcoin vanity"><img src="img/logo.jpg" alt="bitcoin vanity" title="bitcoin vanity" border="0"></a></td>
<td width="20%" class="genmed" valign="top">
<br><br>
<table>
<tr>
<td colspan="3" class="grey"><b>Case sensitive:</b></td>
</tr>
<tr>
<td class="grey">1&nbsp;&nbsp;</td><td class="grey"> free</td>
</tr>
<tr>
<td class="grey">2</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">3</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">4</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">5</td><td class="grey" style="color:#00cc00">free </td>
</tr>
<tr>
<td class="grey">6</td><td class="grey">0.06 BTC</td>
</tr>
<tr>
<td class="grey">7</td><td class="grey">0.4 BTC</td>
</tr>
<tr>
<td class="grey">8</td><td class="grey">1.7 BTC</td>
</tr>
<tr>
<td class="grey">9</td><td class="grey">impossible for now</td>
</tr>
</table>
</td>
</tr>
<tr>
<td colspan="6" width="60%" class="tyxt">
<br>
<b>What is a Vanity Address?</b><br>
It's a normal bitcoin address that starts with some string of characters that appeals to you.<br>
In some way it is a bit like having a personalised number plate on your car.<br><br>
<b>Paper Wallet</b><br>
With your vanity address, you automatically receive paper wallet. You can print it and fold like below. <br>More informations about paper wallet is in our <a href="faq.php" alt="Bitcoin Vanity Address" title="Bitcoin Vanity Address"><span style="color:#"><b><u>FAQ</u></b></span></a><br>
<div style="padding-left:10px;padding-top:5px;"><img src="img/view.png" style="width:50%;height:50%;" title="bitcoin paper wallet" alt="bitcoin paper wallet" border="0"></div><br><br>
<b>Delivery method</b><br>
When your vanity address is ready, you will receive it by chosen delivery method:<br>
1. Email (one time link to receive your address)<br>
2. Traditional post (whole world delivery)<br>
3. Contact us and suggest another option<br><br>
<b>How to import a Private Key into a Wallet?</b><br>
<script type="text/javascript">
<!--
        function showhide5(targetID) {
                //change target element mode
                var elementmode = document.getElementById(targetID).style;
                elementmode.display = (!elementmode.display) ? 'none' : '';
        }
        function hide5(targetID) {
                //change target element mode
                var elementmode = document.getElementById(targetID).style;
                elementmode.display = 'none';
        }
-->
</script>
<br>
<table style="padding: 10px;" align="center" width="100%">
<tr>
<td class="boxx" align="center"><a href="javascript:showhide5(35);javascript:hide5(33);javascript:hide5(34);javascript:hide5(36);">Blockchain.info <span style="color:#00ee00;font-size:11px;">(easy)</span></a></td>
<td class="boxx" align="center"><a href="javascript:showhide5(33);javascript:hide5(35);javascript:hide5(34);javascript:hide5(36);">Bitcoin Core <span style="color:#FFA500;font-size:11px;">(medium)</span></a></td>
<td class="boxx" align="center"><a href="javascript:showhide5(34);javascript:hide5(33);javascript:hide5(35);javascript:hide5(36);">MultiBit <span style="color:#FFA500;font-size:11px;">(medium)</span></a></td>
<td class="boxx" align="center"><a href="javascript:showhide5(36);javascript:hide5(33);javascript:hide5(35);javascript:hide5(34);">Electrum <span style="color:#00ee00;font-size:11px;">(easy)</span></a></td>
</tr>
<tr style="display: none;" id="36">
<td colspan="6" class="boxx">
<h2>How to import a private key into <a href="https://electrum.org/" alt="Electrum Bitcoin wallet client" target="_blank"><span style="font-size:20px;">Electrum</span></a></h2>
<p>The easiest way:</p>
<ol>
<li>Follow basic configuration after install</li>
<li>Click Wallet --> Private Keys --> Import --> Click YES</li>
<li>Paste your private key and click Import</li>
<li>Wait for synchronization</li>
<li>Done</li>
</ol>
</td>
</tr>
<tr style="display: none;" id="33">
<td colspan="6" class="boxx">
<h2>How to import a single private key into <a href="https://bitcoin.org/en/download" alt="Bitcoin wallet client" target="_blank"><span style="font-size:20px;">Bitcoin Core</span></a></h2>
<h3>Debug Window</h3>
<ol>
<li>Open Debug Window</li>
<li>Go to menu: /Help/Debug Window <br>
<img src="img/bitcoin-address-generator-1.png" alt="bitcoin address generator" title="bitcoin address generator"></li>
<li>Click on the tab - Console</li>
</ol>
<h3>If your wallet is encrypted</h3>
<ol>
<li>If your wallet is encrypted you must unlock it. If not just skip this section. </li>
<li>To unlock wallet, just type into the box at the bottom:<br><span style="color:#ccc"> walletpassphrase "YourPassphrase" 600</span></li>
<li>(The 600 means your wallet is unlocked for 10 minutes (600 seconds)) <br>
<img src="img/bitcoin-address-generator-2.png" alt="bitcoin address generator" title="bitcoin address generator"></li>
</ol>
<h3>Run Import Command in Debug Window</h3>
<ol>
<li>In the console at the very bottom is a text entry box. In here enter:<br><span style="color:#ccc">importprivkey yourPrivateKey "TheLabelThatIWant"</span><br>
<img src="img/bitcoin-address-generator-3.png" alt="bitcoin address generator" title="bitcoin address generator"></li>
<li>You now have to be patient. On a fast PC it takes 2 minutes to import, and during this time it looks like you application has hung. After waiting a few minutes you will see:<br>
<img src="img/bitcoin-address-generator-4.png" alt="bitcoin address generator" title="bitcoin address generator"></li>
<li>The End</li>
</ol>
<h2>(Optional) Check if Private Key is Imported</h2>
<ol>
<li>Once Imported you can check that you have the address by closing the Debug window and going back to your address book</li>
<li>You should see the address here:<br>
<img src="img/bitcoin-address-generator-5.png" alt="bitcoin address generator" title="bitcoin address generator"></li>
</ol>
</td>
</tr>
<tr style="display: none;" id="34">
<td colspan="6" class="boxx">
<h2>How to import a single private key into <a href="https://multibit.org/" alt="Bitcoin wallet client" target="_blank"><span style="font-size:20px;">MultiBit</span></a></h2>
<p>The easiest way:
</p><ol>
<li>Create a new wallet saved to a file, say, example.wallet.</li>
<li>Export the private keys, WITHOUT A PASSWORD, to a file example.key.</li>
<li>Open up the key file in a text editor. There is a big comment at the top that describes the format. It is simply
lines, each line containing the sipa format key - beginning with 5 - and the key creation date in a particular
format. You will have an example in there to copy as a new wallet has one key in it.
</li>
<li>Add in your new key and a date a bit before when you created it.</li>
<li>Import the example.key file back into the wallet.</li>
<li>MultiBit will then replay the blocks to get the transactions and work out the balance.</li>
</ol>
</td>
</tr>
<tr style="display: none;" id="35">
<td colspan="6" class="boxx">
<h2>How to import your private key into <a href="https://blockchain.info/" alt="Bitcoin wallet client" target="_blank"><span style="font-size:20px;">Blockchain.info normal wallet</span></a></h2>
<p>The easiest way:</p>
<ol>
<li>log into your <a href="https://blockchain.info/wallet" alt="Bitcoin wallet client" target="_blank">blockchain.info normal wallet</a> account</li>
<li>click Import / Export</li>
<li>click Import</li>
<li>paste your private key into Import Private Key box</li>
<li>click Add Private Key</li>
<li>click Import Directly</li>
</ol>
<h2>How to import a single private key into <a href="https://blockchain.info/" alt="Bitcoin wallet client" target="_blank"><span style="font-size:20px;">Blockchain.info *new* wallet</span></a></h2>
<p>The easiest way:</p>
<ol>
<li>log into your <a href="https://blockchain.info/wallet" alt="Bitcoin wallet client" target="_blank">blockchain.info *new* wallet</a> account</li>
<li>click SETTINGS</li>
<li>click Addresses</li>
<li>click Manage Addresses button next to Imported Addresses</li>
<li>click Import Address button</li>
<li>paste your private key</li>
<li>click Import</li>
</ol>
</td>
</tr>
</table>
<br><br>
<b>Security</b><br>
Security is our top priority. After address generation is complete we send it to you with chosen delivery method.<br>
Our automatic process delete every trace of generation.<br><br>
<b>Forbidden characters</b><br>
Bitcoin addresses consist of random digits and uppercase and lowercase letters, with the exception that the<br>
uppercase letter "O", uppercase letter "I", lowercase letter "l", and the number "0" are never used to prevent visual ambiguity.<br><br>
<b>Longer and cheaper Vanity Address</b><br>
We are in process of expanding our infrastructure to allow even longer Vanity Addresses at lower prices.<br><br>
<b>Contact</b><br>
If you have any suggestions or questions use our <a href="contact.php" alt="Contact" title="contact"><b>Contact Form</b></a><br><br>
</td>
</tr>
<tr>
<td colspan="6" width="60%" style="adding-left: 150px;">
<br>
<div align="center"><a href="index.php">Back</a></div>
</td>
</tr>
<tr>
<td colspan="6" align="center" id="28582">
<br><br><br><br><br><br>
<span style="color:#00cc00">Six letters vanity address is now FREE</span>
<br><br>
<span style="color:#979797">Generated: <b>25556</b> Queue: <b>0</b></span>
<br><br><br><br><br>
<span style="color: #757575;">Donations: <a href="https://blockchain.info/address/1VanityeNpkB3BwFXCDynrejjQYpyDTz7" alt="bitcoin vanity address example" title="bitcoin vanity address example" target="_blank"><span style="color:#757575">1<b>Vanity</b>eNpkB3BwFXCDynrejjQYpyDTz7</span></a><br>
Created by <a href="http://versero.pl" alt="server administration, security" title="server administration, security" target="_blank"><span style="color:#979797">versero.pl</span></a> &copy; websites, server administration, security
<br><br><br><br><br><br>
<table style="width:600px;" align="center">
<tr>
<td valign="top" style="width:30%;color:#757575;">
<h4>Informations</h4>
 
<a href="vanity-bulk.php" alt="Bitcoin bulk vanity" title="Bitcoin bulk vanity"><span style="color:#757575">Bulk Generation</span></a><br>
<a href="faq.php" alt="Bitcoin faq" title="Bitcoin faq"><span style="color:#757575">FAQ</span></a><br>
<a href="contact.php" alt="Bitcoin Vanity Address Generator Online" title="Bitcoin Vanity Address Generator Online"><span style="color:#757575">Contact Us</span></a>
</td>
<td>&nbsp;&nbsp;</td>
<td valign="top" style="width:30%;color:#757575;">
<h4>Dictionary</h4>
<a href="bitcoin-vanity-address.php" alt="Bitcoin Vanity Address" title="Bitcoin Vanity Address"><span style="color:#757575">Vanity Address</span></a><br>
<a href="bitcoin-paper-wallet.php" alt="Bitcoin Paper Wallet" title="Bitcoin Paper Wallet"><span style="color:#757575">Paper Wallet</span></a><br>
</td>
<td>&nbsp;&nbsp;</td>
<td valign="top" style="width:30%;color:#757575;">
<h4>Follow Us</h4>
<a href="https://twitter.com/BitcoinVanity" alt="Bitcoin Vanity Address" title="Bitcoin Vanity Address" target="_blank"><span style="color:#757575">Twitter</span></a>
</td>
</tr>
</table>
<br><br><br>
<div align="center" style="color:#555"><b>2014-2017</b></div>
<br><br><br>
</span>
</td>
</tr>
</table>
</body>
</html>
