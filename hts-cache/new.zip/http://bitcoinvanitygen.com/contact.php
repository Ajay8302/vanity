 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>BitcoinVanityGen.com - Bitcoin Vanity Address Generator Online, Free Bitcoin Vanity Address Generaton</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta name="robot" content="index, follow">
<meta name="Description" content="Bitcoin vanity address generator online, secure, easy, fast and free. Generate your Bitcoin address online"/>
<meta name="Keywords" content="bitcoin vanity address generator online, bitcoin, vanity, address, generator, custom address, custom bitcoin address, bitcoin vanity address generator, bitcoin vanity address, bitcoin vanity, bitcoin address generator, free bitcoin address, online, free"/>
<link rel="stylesheet" href="btc.css" type="text/css">
<link rel="stylesheet" href="pure.css">
</head>
<body style="margin: 0px; padding 0px;background: #454545;">
<table width="60%" align="center" border="0" cellspacing="0" cellpadding="0">
<tr id="5228582">
<td align="center" colspan="6">
<br><br><br>
<a href="bitcoinvanityaddress.php" alt="Bitcoin Vanity Address FAQ" title="Bitcoin Vanity Address FAQ"><span style="color: #979797;">What is Bitcoin Vanity address? | FAQ | Contact</span></a>
<br><br>
</td>
</tr>
<tr id="55252">
<td width="20%" align="right" class="genmed" valign="top">
<br><br>
<table>
<tr>
<td colspan="3" class="grey"><b>Characters:</b></td>
</tr>
<tr>
<td class="grey">1&nbsp;&nbsp;</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">2</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">3</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">4</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">5</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">6 </td><td class="grey" style="color:#00cc00">free</td>
</tr>
<tr>
<td class="grey">7</td><td class="grey">0.06 BTC</td>
</tr>
<tr>
<td class="grey">8 </td><td class="grey">0.3 BTC</td>
</tr>
<tr>
<td class="grey">9</td><td class="grey">0.8 BTC</td>
</tr>
</table>
</td>
<td width="20%" align="center"><a href="index.php" alt="bitcoin vanity" title="bitcoin vanity"><img src="img/logo.jpg" alt="bitcoin vanity" title="bitcoin vanity" border="0"></a></td>
<td width="20%" class="genmed" valign="top">
<br><br>
<table>
<tr>
<td colspan="3" class="grey"><b>Case sensitive:</b></td>
</tr>
<tr>
<td class="grey">1&nbsp;&nbsp;</td><td class="grey"> free</td>
</tr>
<tr>
<td class="grey">2</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">3</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">4</td><td class="grey">free</td>
</tr>
<tr>
<td class="grey">5</td><td class="grey" style="color:#00cc00">free </td>
</tr>
<tr>
<td class="grey">6</td><td class="grey">0.06 BTC</td>
</tr>
<tr>
<td class="grey">7</td><td class="grey">0.4 BTC</td>
</tr>
<tr>
<td class="grey">8</td><td class="grey">1.7 BTC</td>
</tr>
<tr>
<td class="grey">9</td><td class="grey">impossible for now</td>
</tr>
</table>
</td>
</tr>
<tr>
<td colspan="6" width="60%" class="tyxt" align="center">
<br><br>
<form class="pure-form pure-form-aligned" action="contact.php" method="post">
<fieldset>
<div class="pure-control-group">
<label for="gen">Name</label>
<input id="name" name="name" placeholder="Your name" style="width:380px;color:#000" type="text">
</div>
<script type="text/javascript">
  document.getElementById("name").focus();
</script>
<div class="pure-control-group">
<label for="ex">Email</label>
<input id="email" name="email" placeholder="Your email" style="width:380px;color:#000;" type="text">
</div>
<div class="pure-control-group">
<label for="ex">Repeat Email</label>
<input id="email2" name="email2" placeholder="Repeat your email" style="width:380px;color:#000;" type="text">
</div>
<div class="pure-control-group">
<label for="ex"> <img src="img/captcha.png" style="width:100px; height:30px;"></label>
<input id="captcha" name="captcha" placeholder="Text from image" style="width:380px;color:#000;" type="text">
</div>
<div class="pure-control-group" s="">
<label for="price">Message</label>
<textarea name="message" id="message" placeholder="Type your message" style="width:380px;height:200px;color:#000;" rows="15" cols="35" wrap="virtual" tabindex="3" type="text"></textarea>
</div>
</fieldset></td>
</tr>
<tr>
<td colspan="6" align="center" width="100%">
<div class="pure-controls">
<button type="submit" class="pure-button pure-button-primary">Send</button>
</div>
</form>
</td>
</tr>
<tr>
<td colspan="6" align="center" id="28582">
<br><br><br><br><br><br>
<span style="color:#00cc00">Six letters vanity address is now FREE</span>
<br><br>
<span style="color:#979797">Generated: <b>25556</b> Queue: <b>0</b></span>
<br><br><br><br><br>
<span style="color: #757575;">Donations: <a href="https://blockchain.info/address/1VanityeNpkB3BwFXCDynrejjQYpyDTz7" alt="bitcoin vanity address example" title="bitcoin vanity address example" target="_blank"><span style="color:#757575">1<b>Vanity</b>eNpkB3BwFXCDynrejjQYpyDTz7</span></a><br>
Created by <a href="http://versero.pl" alt="server administration, security" title="server administration, security" target="_blank"><span style="color:#979797">versero.pl</span></a> &copy; websites, server administration, security
<br><br><br><br><br><br>
<table style="width:600px;" align="center">
<tr>
<td valign="top" style="width:30%;color:#757575;">
<h4>Informations</h4>
 
<a href="vanity-bulk.php" alt="Bitcoin bulk vanity" title="Bitcoin bulk vanity"><span style="color:#757575">Bulk Generation</span></a><br>
<a href="faq.php" alt="Bitcoin faq" title="Bitcoin faq"><span style="color:#757575">FAQ</span></a><br>
<a href="contact.php" alt="Bitcoin Vanity Address Generator Online" title="Bitcoin Vanity Address Generator Online"><span style="color:#757575">Contact Us</span></a>
</td>
<td>&nbsp;&nbsp;</td>
<td valign="top" style="width:30%;color:#757575;">
<h4>Dictionary</h4>
<a href="bitcoin-vanity-address.php" alt="Bitcoin Vanity Address" title="Bitcoin Vanity Address"><span style="color:#757575">Vanity Address</span></a><br>
<a href="bitcoin-paper-wallet.php" alt="Bitcoin Paper Wallet" title="Bitcoin Paper Wallet"><span style="color:#757575">Paper Wallet</span></a><br>
</td>
<td>&nbsp;&nbsp;</td>
<td valign="top" style="width:30%;color:#757575;">
<h4>Follow Us</h4>
<a href="https://twitter.com/BitcoinVanity" alt="Bitcoin Vanity Address" title="Bitcoin Vanity Address" target="_blank"><span style="color:#757575">Twitter</span></a>
</td>
</tr>
</table>
<br><br><br>
<div align="center" style="color:#555"><b>2014-2017</b></div>
<br><br><br>
</span>
</td>
</tr>
</table>
</body>
</html>
